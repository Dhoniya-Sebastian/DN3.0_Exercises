package main.java.com.example.bookstoreapi.security;

public class JwtRequest {
    private String username;
    private String password;

    // Getters and Setters
}